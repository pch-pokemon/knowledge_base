# Effect of ppm-level La modification on hot corrosion behaviour of single crystal superalloy CMSX-4

Jiangkun Fan ${}^{a, b, c, * }$ , Jiayu Li ${}^{a}$ , Yuelin Song ${}^{a}$ , Dian Jiao ${}^{a}$ , Zhiying Zhu ${}^{a}$ , Xiao Ma ${}^{a}$ , Ruihao Yuan ${}^{a, b, c}$ , Jianbo Yu ${}^{d}$ , Jun Wang ${}^{a, b, c}$ , Hongchao Kou ${}^{a, b, c}$ , Zhongming Ren ${}^{d}$ , Jinshan Li ${}^{\mathrm{a},\mathrm{b},\mathrm{c}}$

${}^{a}$ State Key Laboratory of Solidification Processing, Northwestern Polytechnical University, Xi'an 710072, China

${}^{b}$ National & Local Joint Engineering Research Center for Precision Thermoforming Technology of Advanced Metal Materials, Xi'an 710072, China

${}^{\mathrm{c}}$ Chongqing Innovation Center, Northwestern Polytechnical University, Chongqing 401135, China

${}^{d}$ State Key Laboratory of Advanced Special Steels, School of Materials Science and Engineering, Shanghai University, Shanghai 200072, China

## ARTICLEINFO

Keywords:

Ni-based single-crystal superalloy

Hot corrosion

Rare-earth elements

Corrosion products

CMSX-4

## A B S T R A C T

Doping with trace levels of rare earth elements is an effective approach to enhancing the oxidation and hot corrosion resistance of superalloys. In this study, the hot corrosion behaviour of ppm lanthanum (La) (0 ppm, 40 ppm, and 200 ppm) modified CMSX-4 superalloy and the action micro-mechanism of La were systematically clarified and summarised by SEM, EDS, EPMA, FIB and TEM. The results indicated that ppm-level La doping significantly decreased the corrosion rate of the alloy by more than half. However, increasing the doping level of La does not affect the hot corrosion kinetics of the modified alloys. Compared to unmodified alloys, La-modified alloys exhibit a denser and more complete surface corrosion product, resulting in longer weight gain "plateaus" on the weight gain curves. Further analysis shows La segregation provides a short-circuit diffusion channel for oxygen and promotes the external diffusion of Al, Ti, and Ta, thereby improving the integrity and densification of the protective oxide film. The hot corrosion reaction of the alloy with lower La content ( ${40}\mathrm{{ppm}}$ ) is generally more stable.

## 1. Introduction

Ni-based single-crystal (SC) superalloys possess excellent thermo-mechanical properties and oxidation resistance at high temperatures, making them the preferred materials for hot-section components, particularly turbine blades in advanced aero-engines and gas turbine engines $\left\lbrack  {1,2}\right\rbrack$ . Turbine parts are exposed to increasingly harsh service environments that require the material to withstand cyclic loads and high-temperature gas corrosion over extended periods [3]. Hot corrosion is an accelerated corrosion behaviour caused by molten salt deposits formed on alloy surfaces in high-temperature oxidising atmospheres [4]. There are two general types of hot corrosion: Type I hot corrosion at $\sim  {750}^{ - }{900}^{ \circ  }\mathrm{C}$ and Type II hot corrosion at $\sim  {600} - {800}^{ \circ  }\mathrm{C}$ $\left\lbrack  {5,6}\right\rbrack$ . In the case of Type I, ${\mathrm{{Na}}}_{2}{\mathrm{{SO}}}_{4}\left( {{T}_{m} = {884}^{ \circ  }\mathrm{C}}\right)$ is in a molten state, and the molten salt interacts with the alloy surface to cause corrosion, which is characterized by alkaline melt, internal sulphide and porous external film, and the corrosion process is divided into two stages: the initiation stage and the propagation stage [7]. During combustion, impurities such as $\mathrm{S},\mathrm{{Cl}},\mathrm{{Na}}$ , and $\mathrm{K}$ present in the fuel react with atmospheric ${\mathrm{O}}_{2}$ and $\mathrm{{NaCl}}$ (in marine environments) to form sulphate deposits, commonly ${\mathrm{{Na}}}_{2}{\mathrm{{SO}}}_{4}$ $\left\lbrack  {7,8}\right\rbrack$ . Sulphate is the primary corrosive medium in the service environments of single-crystal blades. When chloride salts are present in the corrosive medium, $\mathrm{{NaCl}}$ participates in the reaction, forming volatile chlorides. This process reduces the latency period and accelerates the corrosion reaction [9-12]. Consequently, the hot corrosion reaction disrupts the protective oxide film on the surface of the alloy, leading to accelerated degradation, reduced load-carrying capacity of the components, and eventual premature failure.

The compositional adjustment window for Ni-based SC superalloys is quite narrow [13-15]. Therefore, the development of low-cost, low-- density Ni-based SC superalloys is a common goal. Some low-generation Ni-based SC superalloys with excellent properties have been optimised through compositional design. The aim has been to maintain a low Re content while maintaining the high-temperature oxidation and corrosion resistances of said alloys. Strategies include increasing Cr content and considering the synergistic effects of refractory elements such as Ta, W, and Mo [16]. Among the above-mentioned superalloys, the most commonly used is the second-generation SC superalloy containing 3 wt% Re [17]. CMSX-4 serves as an example of a typical second-generation SC superalloy, displaying excellent mechanical properties. However, its low Cr content results in a relatively poor hot corrosion resistance $\left\lbrack  {{18},{19}}\right\rbrack$ . To enhance the corrosion resistance of the alloy, a systematic study of its hot corrosion behaviour at the service temperature is necessary. More critically, corrosion and mechanical loading can act synergistically, leading to an abrupt loss of performance [20]. For example, Yang et al. [21] showed that in molten-salt environments hot corrosion markedly reduces the material's flow stress, and that creep failure exhibits a pronounced stress dependence. In the case of fatigue, stress-assisted SOx ingress locally liquefies the alloy at the crack tip, embrittling the tip, re-orienting crack growth from $< {111} >$ to $< {100} >$ , and sharply accelerating crack propagation [22]. These findings underline that a thorough understanding of hot-corrosion behaviour is essential for the safe service of critical components.

---

* Corresponding author at: State Key Laboratory of Solidification Processing, Northwestern Polytechnical University, Xi'an 710072, China.

E-mail address: jkfan@nwpu.edu.cn (J. Fan).

---

Previous studies have suggested that doping with trace amounts (ppm-level) of rare earth elements (REs) can significantly enhance the high-temperature mechanical properties [23,24] and oxidation resistance of Ni-based superalloys [25-27]. However, excessive doping can lead to property deterioration; thus, it is crucial to determine critical doping values. Many researchers have attributed the effects of REs to the reactive element effect (REE), which has received significant attention [28-31]. Similarly, environmental modification via REs doping has been observed in Ni-based SC superalloys. For example, Shi et al. [32] discovered that adding a trace amount of $\mathrm{Y}$ improved the gas corrosion performance of a Ni-based SC superalloy at ${900}^{ \circ  }\mathrm{C}$ . Despite its lower Cr content than that of the DD6 alloy, Li et al. [33] demonstrated that the oxidation resistance of the single-crystal DD9 alloy was reversed after modification with 0.001 wt% Y. Seybolt et al. [34] proposed that adding small amounts of rare earth oxides to the Ni-based superalloys can effectively absorb sulphur and reduce internal sulphide, thereby improving hot corrosion resistance. Harris et al. [35] reported that the commercial CMSX-4 alloy also achieved enhanced high-temperature performance by incorporating trace amounts of La and Y. Additionally, synergistic effects may exist among the various REs, as the alloy simultaneously doped with two different REs demonstrated a more significant improvement. It's encouraging that addition of ppm-level REs may significantly improve the oxidation resistance, which has been proved in the early age. In that case, it's worthy to discuss whether ppm-level Res has a similar improvement effect on hot corrosion performance since little attention was paid on it. Moreover, due to the difficulty of REs doping technology and trace element characterization technology, there is evident lack of reports on the action mechanism of ppm-level REs on hot corrosion behaviour.

In summary, trace REs doping has become an accepted method for material modification, but where ppm REs are distributed, in what form it appears, and how it functions remain elusive. This remains a scientific and engineering application problem that has not yet been completely solved, even for the more mature 2nd generation SC superalloys.

This study aimed to investigate the influence of ppm-level La doping on the Type I hot corrosion behaviour of the CMSX-4 superalloy. Since the action mechanism of ppm-level REs on hot corrosion behaviour has never been fully revealed, this study focuses on capturing evident effects of La-modification, and propose a groundbreaking insight from a microstructural perspective. First, the hot corrosion behaviours of the unmodified and modified CMSX-4 alloy were assessed in a ${90}\mathrm{{wt}}\%$ ${\mathrm{{Na}}}_{2}{\mathrm{{SO}}}_{4} + {10}\mathrm{{wt}}\% \mathrm{{NaCl}}$ mixture at ${900}^{ \circ  }\mathrm{C}$ . Subsequently, the relationship between the morphology and structure of complex-surface corrosion products was established using various surface detection methods. The modification effect and possible mode of action resulting from REs doping are discussed from a microstructural perspective. Additionally, a statistical analysis characterised the influence of the doping amount of REs on the stability of the hot corrosion performance improvement. The results are useful for composition design and service performance optimisation of Ni-based SC superalloys.

## 2. Experimental

The 2nd generation Ni-based SC CMSX-4 superalloy was used as the substrate material. Two groups of modified alloy bars, designated as LaMA40 and LaMA200, were doped with ${40}\mathrm{{ppm}}$ and ${200}\mathrm{{ppm}}$ of La, respectively. During the directional solidification process, the master alloy was melted using a high-vacuum cold crucible melting device, and La elements at ${40}/{200}\mathrm{{ppm}}$ were added via wire feeding. Precise control of the trace rare earth element addition was achieved through continuous monitoring via gas-phase mass spectrometry. Subsequently, glow discharge mass spectrometry (GDMS) was used to detect the content and uniformity of La in the alloy. The nominal chemical compositions of the three Ni-based SC superalloys are listed in Table 1. All SC superalloy bars had a size of ${\phi 15}\mathrm{\;{mm}} \times  {300}\mathrm{\;{mm}}$ with a [001] crystal orientation. To homogenise the alloy, the ingots underwent the following heat treatment steps: ${1280}{}^{ \circ  }\mathrm{C}/1\mathrm{\;h} + {1290}{}^{ \circ  }\mathrm{C}/2\mathrm{\;h} + {1300}{}^{ \circ  }\mathrm{C}/6\mathrm{\;h} + \mathrm{{AC}}$ (solution treatment), followed by ${1140}{}^{ \circ  }\mathrm{C}/4\mathrm{\;h} + \mathrm{{AC}}$ and ${870}{}^{ \circ  }\mathrm{C}/{16}\mathrm{\;h} + \mathrm{{AC}}$ (ageing). Subsequently, the SC bars were machined into specimens with a size of ${10} \times  {10} \times  3\mathrm{\;{mm}}$ , with [001] orientation perpendicular to the ${10} \times  3\mathrm{\;{mm}}$ plane, using wire cutting. Before testing, all specimen’ surfaces were polished successively with finer abrasive papers up to ${800}\#$ , facilitating salt adhesion. Subsequently, the specimens were cleaned with alcohol and acetone sequentially using an ultrasonic cleaning machine.

The hot corrosion tests were conducted following the "deposit recoat" method $\left\lbrack  {{36},{37}}\right\rbrack$ in a KSL-1400X muffle furnace. Based on the actual service environment of the alloy, this study maintained experimental temperature at a constant ${900}^{ \circ  }\mathrm{C}$ under normal atmosphere; the salt solution consisted of ${90}\mathrm{{wt}}\% {\mathrm{{Na}}}_{2}{\mathrm{{SO}}}_{4} + {10}\mathrm{{wt}}\% \mathrm{{NaCl}}$ , prepared in deionized water. Prior to testing, the ceramic crucible was preheated in a furnace until it reached a constant weight. The initial mass of the specimens was measured using an analytical balance with an accuracy of ${10}^{-5}\mathrm{\;g}$ . Subsequently, the samples were heated to approximately ${120}^{ \circ  }\mathrm{C}$ on a heating plate and sprayed with a mixed salt solution. During the spraying process, the flux of deposits was controlled at (2.0-3.0) $\mathrm{{mg}}/{\mathrm{{cm}}}^{2}$ by weighing several times. This parameter is suitable for accelerated hot corrosion tests in the laboratory [37-39]. The prepared samples were then placed in a muffle furnace and heated at ${900}^{ \circ  }\mathrm{C}$ for different periods ranging from $5\mathrm{\;h}$ to ${200}\mathrm{\;h}$ . During said periods, the samples were removed several times, desalted in boiling water, and weighed. The corrosion kinetic curves of the samples were constructed based on the weight gain per unit area for each period; the experimental workflow is illustrated in Fig. 1. Three parallel tests were conducted for each test condition to minimise experimental errors.

Following the hot corrosion tests, the phase composition of surface products was identified using X-ray diffraction with Co-radiation (XRD, D8 Advance) and a micro-confocal Raman spectrometer (Alpha300R). The identification was further verified and quantified by X-ray photoelectron spectroscopy (XPS, PHI 5000 Versa Probe III). Casa software was used to determine the composition of corrosion products, with the $\mathrm{C}$ $1\mathrm{\;s}$ peak at ${284.5}\mathrm{{eV}}$ used as a reference to calibrate possible charging shifts. The surface and cross-sectional morphologies of the hot corrosion products were observed and analysed using the field emission scanning electron microscope (SEM, ZEISS Gemini 500) and the transmission-electron microscopy (TEM, Talos F200X) equipped with Energy-dispersive X-ray spectrometry (EDS). The TEM specimens were prepared by focused ion beam (FIB, FEI Helios G4 CX), and the cutting direction is perpendicular to the sample surface. The EDS analysis were carried out in both SEM and TEM. To more accurately characterise the microstructure and element distribution of the cross-sectional corrosion layers, a field emission electron probe micro-analyser (EPMA, JXA-iHP200F, Japan) was employed.

Table 1

Nominal compositions of the three Ni-based SC superalloys (wt%).

<table><tr><td>Alloy</td><td>Cr</td><td>W</td><td>Co</td><td>Mo</td><td>Al</td><td>Ti</td><td>$\mathrm{{Ta}}$</td><td>Re</td><td>Hf</td><td>La</td><td>$\mathrm{{Ni}}$</td></tr><tr><td>CMSX-4</td><td>6.5</td><td>6.0</td><td>9.6</td><td>0.6</td><td>5.6</td><td>1.0</td><td>6.5</td><td>3.0</td><td>0.1</td><td>0</td><td>Bal.</td></tr><tr><td>LaMA40</td><td>6.5</td><td>6.0</td><td>9.6</td><td>0.6</td><td>5.6</td><td>1.0</td><td>6.5</td><td>3.0</td><td>0.1</td><td>40 ppm</td><td>Bal.</td></tr><tr><td>LaMA200</td><td>6.5</td><td>6.0</td><td>9.6</td><td>0.6</td><td>5.6</td><td>1.0</td><td>6.5</td><td>3.0</td><td>0.1</td><td>200 ppm</td><td>Bal.</td></tr></table>

![bo_d208ub3ef24c73anbarg_2_240_408_1264_635_0.jpg](images/bo_d208ub3ef24c73anbarg_2_240_408_1264_635_0.jpg)

Fig. 1. Schematic diagram of the hot corrosion experiment workflow.

To investigate the effect of the La doping amount on the stability of the hot corrosion performance, the surface roughness statistics of the La-modified samples after ${200}\mathrm{\;h}$ of hot corrosion were obtained using a $3\mathrm{D}$ optical profilometer. To ensure scientific credibility, two sides (A and B) of each sample were scanned, and two typical areas were selected for each surface. The extent of the corrosion-affected zone was determined by dimensional metrology $\left\lbrack  {{40},{41}}\right\rbrack$ . First, a series of Backscattered Electron (BSE) micrographs was obtained at evenly spaced locations across the entire cross-section. Then, the corrosion depth was recorded at multiple locations (every ${25\mu }\mathrm{m}$ ) of the photos using the Nano Measurer 1.2 software, providing a statistical record. Finally, the Cumulative Probability Distribution (CPD)Cumulative Probability Distribution (CPD) of each data group was calculated using the Origin software.

## 3. Results

### 3.1. Microstructural characterisation of CMSX-4 alloys

The SEM morphologies of the unmodified and modified CMSX-4 alloy after standard heat treatment are shown in Fig. 2(a) and (b), respectively. A uniform two-phase microstructure, comprising $\gamma$ channels and $\gamma$ ’ precipitates was identified, with the $\gamma$ ’ phase exhibiting high squareness. The average size of the $\gamma$ ’ phase in the dendritic region of the modified alloy was approximately ${480}\mathrm{\;{nm}}$ , which was marginally smaller than that of the unmodified alloy (approximately ${550}\mathrm{\;{nm}}$ on average). This may be attributed to the increased temperature interval of the two-phase zone and the increase in the precipitation temperature caused by the addition of La [42]. The addition of ppm-level La not only refined the $\gamma$ ’ precipitates, but also narrowed the $\gamma$ channels, thereby increasing the volume fraction of the strengthening phase and improving the durability of the alloy [43]. The STEM image and EDS mappings of the La-modified alloy shown in Fig. 2(c)-(i) demonstrate that $\mathrm{{Ni}},\mathrm{{Ta}}$ , and $\mathrm{{Al}}$ were primarily located in the $\gamma$ ’ phase, whereas $\mathrm{{Co}}$ , $\mathrm{{Cr}}$ , and Re were mainly located in the $\gamma$ phase, which is consistent with the unmodified alloy as well as former reports [44,45].

#### 3.2.Hot corrosion kinetics

After ${200}\mathrm{\;h}$ of hot corrosion at ${900}^{ \circ  }\mathrm{C}$ , the average weight gain curves of the samples were plotted using the original weight gain data (See figure SI in the Supplementary Materials for details), as shown in Fig. 3 (a). Additionally, the corrosion rate trend was plotted and fitted based on the average hot corrosion rate for each period between 30 and ${200}\mathrm{\;h}$ , as shown in Fig. 3(b). For the La-free alloy, the weight gain before ${30}\mathrm{\;h}$ was unstable owing to the evaporation of the corrosion medium and spalling of the corrosion products, in line with findings reported by Yang et al. [46]. However, after ${50}\mathrm{\;h}$ , the mass gains of the CMSX-4 samples increased uniformly with increasing corrosion time, approaching a parabolic rule. The average hot corrosion rate after ${50}\mathrm{\;h}$ fluctuated and eventually stabilised below ${0.112}\mathrm{{mg}}/{\mathrm{{cm}}}^{2}/\mathrm{h}$ , as indicated by the kinetic curve.

For the La-doped modified alloys, the weight gain data of the three LaMA40 samples showed some dispersion, but the overall trends were similar. Compared to the unmodified alloy, the modified alloys exhibit significantly reduced mass gain rates, maintaining low-level fluctuations throughout the test. These fluctuations are attributed to progressive corrosion, evaporation of corrosive media, and partial dissolution/ spallation of corrosion products. Unlike the unmodified alloy, the average mass of the LaMA40 samples exhibited a stable growth trend before ${100}\mathrm{\;h}$ , which was highly consistent with the parabolic growth law rule, indicating that there was no significant spalling in the early stage. A weight gain plateau occurred between 100 and ${150}\mathrm{\;h}$ , after which the weight gain trend resumed. Regarding the three LaMA200 samples, the weight gain data showed a high degree of consistency before ${70}\mathrm{\;h}$ but exhibited significant differences after ${100}\mathrm{\;h}$ . After polynomial curve fitting, the corrosion kinetic curves of the alloy followed a parabolic law within $0 - {70}\mathrm{\;h}$ . After ${100}\mathrm{\;h}$ , the weight gain curves of the three alloy samples were dispersed, however, their weight gain trends were similar. There was also a "gentle slope" on the weight gain curves, and a "severe corrosion" trend began to occur after the plateau period, resulting in a significant increase in the mass of the samples. Considering the variable trends of the corrosion rates, after ${30}\mathrm{\;h}$ , the weight gain rate of the modified alloys decreased significantly and eventually slowed down, fluctuating below ${0.06} - {0.07}\mathrm{{mg}}/{\mathrm{{cm}}}^{2}/\mathrm{h}$ , with a much smaller fluctuation range compared to the unmodified alloy. Table 2 summarises the average hot corrosion rates of the unmodified alloy and the two groups of La-doped modified alloys during the entire period and the period from 30 to ${200}\mathrm{\;h}$ . Compared to the unmodified alloy, the average hot corrosion rates of both modified alloys decreased. After ${30}\mathrm{\;h}$ of corrosion, the average corrosion rates of the two modified specimens became similar and decreased by more than half of their original values.

![bo_d208ub3ef24c73anbarg_3_230_152_1290_1285_0.jpg](images/bo_d208ub3ef24c73anbarg_3_230_152_1290_1285_0.jpg)

Fig. 2. (a) SEM morphology of unmodified CMSX-4 alloy; (b) SEM morphology of La-modified alloy; (c) HADDF-STEM image and (d)-(i) corresponding EDS mappings of La-modified alloy after standard heat treatment.

![bo_d208ub3ef24c73anbarg_3_227_1568_1293_545_0.jpg](images/bo_d208ub3ef24c73anbarg_3_227_1568_1293_545_0.jpg)

Fig. 3. (a) Hot corrosion kinetic curves and (b) variation trend of average hot corrosion rates of three alloy samples at ${900}\mathrm{{oC}}$ for ${200}\mathrm{\;h}$ .

From a general standpoint, the addition of ppm-level La significantly improved the hot corrosion resistance of the CMSX-4 alloy. A notable improvement is related to the fact that the weight gain curves of all the modified alloy samples exhibit a longer weight gain "plateau" than that of the unmodified alloy, significantly decreasing the hot corrosion rate of the alloy. A comparison of the hot corrosion kinetic curves of the LaMA40 and LaMA200 indicated that different La doping amounts had little influence on their corrosion kinetics. The corrosion kinetic curves can be divided into two stages of initiation and propagation [7]. It should be noted that LaMA200 exhibited better hot corrosion resistance in the initiation stage of corrosion(0 - 70h). However, there were significant individual differences in the propagation stage of the hot corrosion process, suggesting that the modification effect undergone by LaMA200 may not be as stable as that of LaMA40. This is further verified and discussed in subsequent sections.

### 3.3. Characterisation of hot corrosion products

The alloy samples were characterised after undergoing hot corrosion for different periods using Raman spectra and XRD. The results are presented in Fig. 4. The main hot corrosion products developed on the three sample groups had similar phase constituents, including NiO, ${\mathrm{{TiO}}}_{2},\left( {\mathrm{{Ni}}/\mathrm{{Co}}}\right) {\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4},{\mathrm{{NiTiO}}}_{3},{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{3}$ , and Ta oxides. The diffraction peaks of the Ta oxides were weak, indicating a low concentration of these compounds. Diffraction peaks of $\mathrm{{NiO}}$ are evident in the early stage of corrosion but gradually become obscured by Ti-rich phases $\left( {{\mathrm{{TiO}}}_{2}\text{,}}\right.$ ${\mathrm{{NiTiO}}}_{3}$ ) in the later stage. $\mathrm{{Co}}/\mathrm{{Ni}}\left( {{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4}}\right)$ was detected throughout the entire corrosion process, whereas the diffraction peaks of ${\mathrm{{NiTiO}}}_{3}$ and ${\mathrm{{Cr}}}_{2}{\mathrm{O}}_{3}$ began to appear in the middle and late stages of corrosion. Table 3 summarises the results. XPS was used to validate and supplement the XRD and Raman spectra results, as shown in Fig. SII of the Supplementary Material.

### 3.4. Typical surface morphologies

##### 3.4.1.The unmodified CMSX-4 alloy

The typical surface morphologies of the corrosion products on the CMSX-4 specimens after undergoing hot corrosion with ${\mathrm{{Na}}}_{2}{\mathrm{{SO}}}_{4} + \mathrm{{NaCl}}$ at ${900}^{ \circ  }\mathrm{C}$ for ${10}\mathrm{\;h},{50}\mathrm{\;h},{110}\mathrm{\;h}$ , and ${200}\mathrm{\;h}$ are shown in Fig. 5. The EDS results for the selected areas shown in Fig. 5 are listed in Table 4. Spinel-shaped NiO was mainly formed in Region A during the early stages of hot corrosion. At ${50}\mathrm{\;h}$ of corrosion, the formation of ${\mathrm{{NiTiO}}}_{3}$ was observed; it resulted from the reaction of $\mathrm{{NiO}}$ and ${\mathrm{{TiO}}}_{2}$ and exhibiting a smooth-surfaced cubic block morphology (Region B). Clusters of (Ni/ Co) ${\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4}$ were also detected during the same period (Region C). After ${100}\mathrm{\;h}$ , the surface corrosion products mainly consist of irregular clumps of ${\mathrm{{CoCr}}}_{2}{\mathrm{O}}_{4}$ , exhibiting layered-growth characteristics (Region D). After ${200}\mathrm{\;h}$ , the structure was fragmented and a large number of holes appeared (Regions E and F). The EDS results displayed in Table 4 show that as the hot corrosion reaction progressed, the $\mathrm{{Ni}}$ content on the surface gradually decreased, whereas the Co and $\mathrm{{Cr}}$ contents increased, which is consistent with the XRD test results. This suggests that NiO, preferentially formed in the bottom layer, was gradually consumed and covered by formed unconsolidated ${\mathrm{{CoCr}}}_{2}{\mathrm{O}}_{4}$ .

Table 2

Average hot-corrosion rates of three alloy samples for ${200}\mathrm{\;h}$ and from 30 to ${200}\mathrm{\;h}$ .

<table><tr><td rowspan="2">Average hot-corrosion rates/ $\left( {\mathrm{{mg}}/{\mathrm{{cm}}}^{2}/\mathrm{h}}\right)$</td><td colspan="2">Corrosion period</td></tr><tr><td>0-200 h</td><td>${30} - {200}\mathrm{\;h}$</td></tr><tr><td>CMSX-4</td><td>0.1004</td><td>0.0687</td></tr><tr><td>LaMA40</td><td>0.0658</td><td>0.0333</td></tr><tr><td>LaMA200</td><td>0.0578</td><td>0.0312</td></tr></table>

#### 3.4.2. Modified alloys with ppm-level La

The phase composition analysis showed that the surface corrosion products of the modified alloys were similar to those of the untreated alloy. However, there were differences in their typical morphologies. Fig. 6 shows the typical morphologies of several corrosion products, and the EDS analysis results for selected areas in Fig. 6 are listed in Table 5.

No ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ diffraction peaks were found in the XRD pattern, possibly due to its relatively deep location and, hence, being mostly obscured by other outer-layer corrosion products. However, due to the spalling of some surface products, the underlying alumina was exposed in local areas and appeared as fine white crystalline structures, as shown in Fig. 6(a); This morphology remained relatively stable as the corrosion time increased. Fig. 6(b) shows a typical gemstone mosaic morphology. As in the unmodified CMSX-4, Ni/Co $\left( {{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4}}\right)$ was observed throughout the corrosion process. The $\mathrm{{Ni}}/\mathrm{{Co}}\left( {{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4}}\right)$ are formed in the outer layer of the $\mathrm{{Ni}}$ oxide and are often loosely arranged, corresponding to their loose macroscopic structure. As shown in Fig. 6(c), the typical morphology of $\mathrm{{Ni}}/\mathrm{{Co}}\left( {{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4}}\right)$ is spinel-shaped. The layered growth pattern became more evident as corrosion time increased. Corrosion products were observed after ${100}\mathrm{\;h}$ of hot corrosion, as shown in Fig. 6(d). EDS revealed that the main component was ${\mathrm{{NiTiO}}}_{3}$ , which exhibited distinct characteristics with a large petal shape, accompanied by small granular secondary products growing diffusively on its surface. A small damaged area can be observed in the middle of the petal-shaped ${\mathrm{{NiTiO}}}_{3}$ . Point analysis showed that $\mathrm{{Cr}},\mathrm{{Co}}$ , and $\mathrm{O}$ were enriched in the damaged area, likely forming $\left( {\mathrm{{Co}},\mathrm{{Cr}}}\right) \mathrm{O}$ oxides. This phenomenon indicates that the growth of ${\mathrm{{NiTiO}}}_{3}$ occurs after the formation of $\left( {\mathrm{{Co}},\mathrm{{Cr}}}\right) \mathrm{O}$ oxides, which likely results from the reaction between $\mathrm{{NiO}}$ and ${\mathrm{{TiO}}}_{2}$ during hot corrosion.

The previous results indicated that the Ti-rich oxides generated on the surface mainly consisted of ${\mathrm{{TiO}}}_{2}$ , with the content of ${\mathrm{{TiO}}}_{2}$ being relatively high when the corrosion time reached ${200}\mathrm{\;h}$ . Fig. 7 shows the typical ${\mathrm{{TiO}}}_{2}$ morphologies after corrosion durations of ${100}\mathrm{\;h}$ (Fig. 7(a)) and ${200}\mathrm{\;h}$ (Fig. 7(b) and (c)). Among them, the white frame in Fig. 7(a) demarcates the surface scanning area, while the corresponding frame in Fig. 7(c) indicates the magnified view of location C. The morphologies differ, some grow as long sticks, whereas others appear as clumps or laminated sheets. Most of them exhibited smooth and glossy surfaces. According to the contrast of the SE image in Fig. 7(c), ${\mathrm{{TiO}}}_{2}$ appeared to be generated before $\left( {\mathrm{{Co}},\mathrm{{Cr}}}\right) \mathrm{O}$ oxide. Owing to the large spalling area of the loosely-structured $\left( {\mathrm{{Co}},\mathrm{{Cr}}}\right) \mathrm{O}$ oxide, the exposed area of ${\mathrm{{TiO}}}_{2}$ expanded, and part of it became embedded in the $\left( {\mathrm{{Co}},\mathrm{{Cr}}}\right) \mathrm{O}$ oxide. This result also explains how ${\mathrm{{NiTiO}}}_{3}$ forms on $\left( {\mathrm{{Co}},\mathrm{{Cr}}}\right) \mathrm{O}$ oxide.

### 3.5. Cross-sectional morphologies of corrosion products

##### 3.5.1.The unmodified CMSX-4 alloy

Figs. 8 and 9 show the evolution of the morphology and elemental distribution of the cross-sectional corrosion layer between 10 and ${200}\mathrm{\;h}$ of corrosion. As the corrosion time increased, the thickness of the cross-sectional corrosion layer increased gradually, and the corrosion layer can be divided into three distinct regions, as shown in Fig. 9(a). Region I comprised a continuous oxide layer, which was further divided into outer $\mathrm{{Ni}}$ and $\mathrm{{Co}}$ oxides and an inner continuous- ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ film. Region II contained a large number of dispersed alumina particles, with gradually decreasing sizes, from top to bottom. Region III represents the depleted zone close to the unaffected matrix and exhibits a low O content. The EPMA mappings displayed in Fig. 8 and the line scan mappings exhibited in Fig. 9(b) and (d) show that, as the corrosion reaction progressed, the thickness of the continuous oxide film increased, and the layered structure beneath the continuous film, mainly composed of ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ particles (Fig. 9(c)), became more complex. In the later stage of hot corrosion, the outer oxide layer was consumed or peeled off by the molten salt, leading to surface fragmentation and discontinuity. The interior consists of alternating alumina and sulphide enrichment zones, accompanied by a large number of interlayer cracks, as shown in Fig. 9 (c). Additionally, ${\mathrm{{Ta}}}_{2}{\mathrm{O}}_{5}$ enrichment bands are observed in a few regions, as indicated by the arrows in Fig. 9(e).

![bo_d208ub3ef24c73anbarg_5_227_150_1294_1554_0.jpg](images/bo_d208ub3ef24c73anbarg_5_227_150_1294_1554_0.jpg)

Fig. 4. Raman spectra and XRD patterns of three alloy samples after hot corrosion for different periods. (a, b) Raman spectra; (c-e) XRD.

#### 3.5.2. Modified alloy with ppm-level La

Fig. 10 presents the Backscattered Electron (BSE) images of the cross-sectional corrosion layer and the EPMA mappings of the modified alloy after hot corrosion for different times. It is evident that metal cations such as $\mathrm{{Al}},\mathrm{{Cr}},\mathrm{{Ti}}$ , and $\mathrm{{Ta}}$ diffused outwards during the hot corrosion reaction, forming the corresponding oxide layers on the surface. The Al was gradually depleted and diffused near the surface, leading to the formation of a multi-layer ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ structure, as shown in Fig. 10 (b). The sulphide enrichment zone was mainly located at the bottom of the depleted $\mathrm{{Al}}/\gamma$ ’ zone. The cross-sectional corrosion layer of the La-modified alloy showed no obvious corrosion pits or interlayer cracks, unlike the unmodified alloy. Additionally, during each period of the hot corrosion test, the "bud invasion" mechanism of the inner layer ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ was observed. This mechanism involves the growth of ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ into the matrix in a bud-like form, and cracks often appear on the outside due to the high growth stress, as shown in Fig. 11.

Table 3

Corrosion products developed on three alloy samples for different periods (major products in bold).

<table><tr><td rowspan="2">Time/ h</td><td colspan="3">Corrosion products</td></tr><tr><td>CMSX-4</td><td>LaMA40</td><td>LaMA200</td></tr><tr><td>10</td><td>NiO, Co/Ni(Cr ${}_{2}{\mathrm{O}}_{4}$ ), ${\mathrm{{TiO}}}_{2}$</td><td>$\mathrm{{NiO}},\mathrm{{Co}}/\mathrm{{Ni}}\left( {{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4}}\right)$</td><td>NiO, Co/Ni(Cr ${}_{2}{\mathrm{O}}_{4}$ ), ${\mathrm{{NaTaO}}}_{3}$</td></tr><tr><td>50</td><td>$\mathrm{{NiO}},\mathrm{{Co}}/\mathrm{{Ni}}\left( {{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4}}\right)$ , ${\mathrm{{TiO}}}_{2}$ , Ni ${\mathrm{{TiO}}}_{3}$</td><td>$\mathrm{{NiO}},\mathrm{{Co}}/\mathrm{{Ni}}\left( {{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4}}\right)$ , ${\mathrm{{Ta}}}_{2}{\mathrm{O}}_{5}$ , Ti ${\mathrm{O}}_{2}$</td><td>NiO, Co/Ni(Cr ${}_{2}{\mathrm{O}}_{4}$ ), ${\mathrm{{NaTaO}}}_{3}$ , ${\mathrm{{TiO}}}_{2}$ , ${\mathrm{{NiTiO}}}_{3}$ , ${\mathrm{{Cr}}}_{2}{\mathrm{O}}_{3}$</td></tr><tr><td>100</td><td>NiO, ${\mathrm{{TiO}}}_{2}$ , Co/Ni $\left( {{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4}}\right) ,{\mathrm{{Ta}}}_{2}{\mathrm{O}}_{5},$ ${\mathrm{{NiTiO}}}_{3}$</td><td>$\mathrm{{NiO}},\mathrm{{Co}}/\mathrm{{Ni}}\left( {{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4}}\right)$ , ${\mathrm{{Ta}}}_{2}{\mathrm{O}}_{5}$ TiO ${}_{2}$ , NiTiO ${}_{3}$ , ${\mathrm{{Cr}}}_{2}{\mathrm{O}}_{3}$</td><td>$\mathrm{{NiO}},\mathrm{{Co}}/\mathrm{{Ni}}\left( {{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4}}\right)$ , ${\mathrm{{NaTaO}}}_{3}$ , ${\mathrm{{TiO}}}_{2}$ , ${\mathrm{{NiTiO}}}_{3}$ , ${\mathrm{{Cr}}}_{2}{\mathrm{O}}_{3}$</td></tr><tr><td>200</td><td>NiO, ${\mathrm{{TiO}}}_{2}$ , Co/Ni $\left( {{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4}}\right) ,{\mathrm{{Ta}}}_{2}{\mathrm{O}}_{5}$ , ${\mathrm{{NiTiO}}}_{3}$</td><td>$\mathrm{{NiO}},\mathrm{{Co}}/\mathrm{{Ni}}\left( {{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4}}\right)$ , ${\mathrm{{Ta}}}_{2}{\mathrm{O}}_{5}$ TiO ${}_{2}$ , NiTiO ${}_{3}$ , ${\mathrm{{Cr}}}_{2}{\mathrm{O}}_{3}$</td><td>$\mathrm{{NiO}},\mathrm{{Co}}/\mathrm{{Ni}}\left( {{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4}}\right)$ , ${\mathrm{{TiO}}}_{2}$ , ${\mathrm{{NiTiO}}}_{3},{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{3}$</td></tr></table>

Combining the EDS line-scanning patterns, the cross-sectional corrosion layer can be divided into three parts, as illustrated in Fig. 12 (a): Region I represents the outer oxide layer composed of mixed oxides of $\left( {\mathrm{{Ni}},\mathrm{{Co}},\mathrm{{Cr}}}\right) \mathrm{O}$ , it has a relatively loose structure; Region $\mathrm{{II}}$ is a continuous oxide film composed of ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ and ${\mathrm{{Cr}}}_{2}{\mathrm{O}}_{3}$ , exhibiting a relatively dense structure; Region III is the Cr/TiS ${}_{\mathrm{X}}$ sulphide dispersion area. With an increase in the corrosion time, partial segregation of La occurred near the surface, which aligns with the distribution of $\mathrm{{Ti}}$ and Ta. This phenomenon was observed in three typical regions, located at the interface of the corrosion product layers (between Region I and II, as depicted in Fig. 12 (a)), underneath the continuous ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ film (Region II, as depicted in Fig. 12 (b)), and in the outer corrosion layer (Region I, as depicted in Fig. 10 (a) and Fig. 12 (c)). These local areas typically contained a small $\mathrm{{Ti}}/\mathrm{{La}}$ -rich area and a small amount of ${\mathrm{{Ta}}}_{2}{\mathrm{O}}_{5}$ , which were rarely observed in the unmodified CMSX-4 alloy. This observation indicates the effect of La in promoting the outward diffusion of Ti and Ta.

In order to further confirm the composition of various corrosion products, it is necessary to obtain well-documented crystallographic structure information. To this end, FIB-TEM characterization was conducted on the CMSX-4 alloy modified with ${200}\mathrm{{ppm}}$ La after undergoing ${200}\mathrm{\;h}$ of hot corrosion exposure. Fig. 13 presents the high-angle annular dark-field scanning transmission electron microscopy (HAADF-STEM) image and the corresponding EDS element mappings of the FIB sample. The sample was obtained close to the interface of the corrosion layer. As can be observed, $\mathrm{{Cr}},\mathrm{{Ta}},\mathrm{{Ti}},\mathrm{{Ni}}$ and $\mathrm{{Al}}$ are enriched in different regions. TEM selected area electron diffraction (SAED) patterns shows that the corresponding products are ${\mathrm{{Cr}}}_{2}{\mathrm{O}}_{3},{\mathrm{{Ta}}}_{2}{\mathrm{O}}_{5},{\mathrm{{TiO}}}_{2}$ , NiO, and ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ . Combined with the crystallography database, the above crystal structure characteristics are shown in Table 6.

Further TEM characterization was performed on La-containing oxides sectioned by FIB immediately below the $\gamma$ ’ depleted zone, with results presented in Fig. 14. The La-enriched oxide shown in the lower right of Fig. 14(a) was analyzed by EDS (atomic percentages labeled in figure). Through combined HRTEM imaging and diffraction pattern analysis, this phase was identified as hexagonal ${\mathrm{{La}}}_{2}{\mathrm{O}}_{3}$ (space group $\mathrm{P}{3}^{ - }\mathrm{m}1)$ with lattice parameters $\mathrm{a} = {3.93Å},\mathrm{\;b} = {3.93Å}$ , and $\mathrm{c} = {6.11Å}$ , consistent with ICDD PDF database references. These findings demonstrate that La not only segregates in the oxide layer but also exists as discrete La-oxide phases near the oxide-alloy interface.

Table 4

EDS results of hot corrosion products for selected areas in Fig. 5 (at%).

<table><tr><td>Elements</td><td>O</td><td>$\mathrm{{Ni}}$</td><td>Co</td><td>Cr</td><td>Ti</td></tr><tr><td>A</td><td>35.0</td><td>34.23</td><td>15.79</td><td>12.13</td><td>-</td></tr><tr><td>B</td><td>57.4</td><td>18.6</td><td>-</td><td>-</td><td>18.1</td></tr><tr><td>C</td><td>45.2</td><td>12.6</td><td>13.1</td><td>27.7</td><td>-</td></tr><tr><td>D</td><td>45.2</td><td>-</td><td>12.2</td><td>30.7</td><td>-</td></tr><tr><td>E</td><td>47.4</td><td>-</td><td>17.7</td><td>31.0</td><td>-</td></tr><tr><td>F</td><td>23.8</td><td>-</td><td>23.4</td><td>45.2</td><td>-</td></tr></table>

![bo_d208ub3ef24c73anbarg_6_226_1272_1292_872_0.jpg](images/bo_d208ub3ef24c73anbarg_6_226_1272_1292_872_0.jpg)

Fig. 5. Typical surface morphologies for different periods of hot corrosion: (a) ${10}\mathrm{\;h};\left( \mathrm{b}\right) {50}\mathrm{\;h};\left( \mathrm{c}\right) {110}\mathrm{\;h};\left( \mathrm{d}\right) {200}\mathrm{\;h}$ .

![bo_d208ub3ef24c73anbarg_7_230_153_1290_865_0.jpg](images/bo_d208ub3ef24c73anbarg_7_230_153_1290_865_0.jpg)

Fig. 6. Typical surface morphologies of different corrosion products: (a) ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ ; (b) NiO; (c) Ni/Co $\left( {{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4}}\right)$ ; (d) NiTiO ${}_{3}$ .

Table 5

EDS results of hot corrosion products for selected areas in Fig. 6 (at%).

<table><tr><td>Elements</td><td>0</td><td>$\mathrm{{Ni}}$</td><td>Co</td><td>Cr</td><td>Al</td><td>Ti</td></tr><tr><td>A</td><td>46.65</td><td>2.11</td><td>1.72</td><td>2.34</td><td>46.48</td><td>-</td></tr><tr><td>B</td><td>45.70</td><td>-</td><td>1.00</td><td>2.05</td><td>50.42</td><td>-</td></tr><tr><td>C</td><td>37.21</td><td>54.6</td><td>7.76</td><td>-</td><td>-</td><td>-</td></tr><tr><td>D</td><td>29.27</td><td>20.82</td><td>13.81</td><td>27.98</td><td>-</td><td>7.19</td></tr><tr><td>E</td><td>55.24</td><td>17.24</td><td>-</td><td>2.40</td><td>-</td><td>24.55</td></tr><tr><td>F</td><td>51.73</td><td>12.55</td><td>7.09</td><td>14.78</td><td>4.33</td><td>9.36</td></tr></table>

## 4. Discussion

### 4.1. Influence of the La doping amount

#### 4.1.1. Surface roughness after hot corrosion

To further discuss the influence of the La doping amount on the stability of the hot corrosion behaviour mentioned in the previous section, it is necessary to compare the surface roughness after hot corrosion. Fig. 15 illustrates the distribution of the surface relative height of La-modified alloys after hot corrosion. The hot corrosion reaction caused significant surface height fluctuations, and there were substantial differences in the corrosion severity in different areas. Some areas exhibited the formation of thick corrosion products (red areas), whereas spalling occurred in other areas (blue areas). However, each sample has a large flat area (green area). The significant difference between sides A and B of the individual samples may be due to their positions in the crucible during the hot corrosion test, with the side closest to the crucible wall being more prone to flaking. Furthermore, the average values of the roughness data are summarized in Table 7, with detailed data available in Table SI of the Supplementary Material. In Table 7, where Sa represents the surface roughness, $\mathrm{{Sp}}$ indicates the height of the highest point in the region, Sv denotes the absolute value of the lowest depth in the region, Sku represents the sharpness of the surface fluctuation (Sku>3 indicates significant peaks or valleys), and Ssk indicates the asymmetry of the surface height fluctuation (a positive value indicates more peaks upward whereas a negative value indicates more depressions downward). Based on the data, the surface roughness values of the two modified alloy groups are mostly within ${10\mu }\mathrm{m}$ . However, owing to the presence of thicker corrosion products and spalling in local areas, the average roughness values may be higher. Compared with the mean value of each data group, LaMA40 exhibited relatively better surface flatness, as indicated by the lower Sa mean value, smaller mean difference between $\mathrm{{Sp}}$ and $\mathrm{{Sv}}$ , and smaller $\mathrm{{Ssk}}$ mean value.

#### 4.1.2. Determine of corrosion depth and corrosion-products thickness

The CPD determines the number of observed values below a given corrosion depth and provides the probability that the corrosion depth is below that value. The cumulative probability (percentage) was taken as the $\mathrm{x}$ -axis, and the corrosion depth was taken as the $\mathrm{y}$ -axis in the distribution diagram. Therefore, the flatter the curve, the higher is the number of data points in the corresponding corrosion depth interval, defining a high-frequency data interval. This work determines the outer/ inner corrosion product layer (CP thickness), sulphide-affected zone $(\gamma$ ’ depleted zone), and total corrosion-affected zone (total corrosion depth) based on the actual situation of the corrosion layers (See figure SIII in the Supplementary Materials for details).

Fig. 16 (a, b) illustrates the distribution of the total corrosion depth and CP thickness of the two modified alloy groups during the three corrosion periods. As the corrosion duration reached ${100}\mathrm{\;h}$ , the total corrosion depth of both groups increased significantly, with more than two high-frequency intervals appearing, resulting in steeper curves and indicating a poor uniformity of the corrosion layer. The CPD curves for the corrosion duration of ${10}\mathrm{\;h}$ and ${50}\mathrm{\;h}$ were similar in shape, with the 50-h high-frequency interval being slightly higher. Therefore, under the experimental conditions, the incubation period of the hot corrosion reaction can be assumed to be between ${50}\mathrm{\;h}$ and ${100}\mathrm{\;h}$ .

![bo_d208ub3ef24c73anbarg_8_122_154_1502_811_0.jpg](images/bo_d208ub3ef24c73anbarg_8_122_154_1502_811_0.jpg)

Fig. 7. (a) $\sim$ (c) Typical surface morphologies of ${\mathrm{{TiO}}}_{2}$ ; (d) EDS results for selected areas.

The effects of different La-doping amounts on CP thickness and total corrosion depth are compared in Fig. 16 (c) and 16 (d). LaMA40 exhibited a lower CP thickness and total corrosion depth than LaMA200. After ${100}\mathrm{\;h}$ of corrosion, LaMA200 experienced serious attack, resulting in a higher total corrosion depth and CP thickness; this indicates that the corrosion layer of LaMA40 exhibits higher uniformity and a more stable hot corrosion resistance. Additionally, for LaMA200, the slope of the ${50}\mathrm{\;h}$ CPD curve was evidently higher than that of the ${10}\mathrm{\;h}$ CPD curve, suggesting a shorter incubation period. This finding is in accordance with the conclusions drawn from the corrosion kinetic curves (Fig. 3(b)).

Comparing the thicknesses of the inner CP layers (intrusion depth) and outer CP layers allows for the direct observation of the spalling of the outer CP layer and the corrosion rate of the inner layer. Fig. 16 (e, f) reveals that the outer CP thickness of LaMA200 remained very similar in the three corrosion periods, suggesting the occurrence of outer CP spalling at the early corrosion stage, resulting in more surface defects and slower CP thickness growth. This phenomenon likely contributes to rapid internal corrosion. The outer CP thickness of LaMA40 increases more from ${10}\mathrm{\;h}$ to ${50}\mathrm{\;h}$ , providing better protection. However, said thickness decreases at ${100}\mathrm{\;h}$ , indicating more spalling of the outer CP during the corrosion period from ${50}\mathrm{\;h}$ to ${100}\mathrm{\;h}$ and leading to more severe internal corrosion during this period.

### 4.2. Mechanism of hot corrosion process

The fluxing mechanism is commonly used to explain hot corrosion at high temperatures. The core of this theory involves comparing the decomposition of ${\mathrm{{Na}}}_{2}{\mathrm{{SO}}}_{4}$ at high temperatures with the decomposition of water, with ${\mathrm{{Na}}}_{2}\mathrm{O}$ in the decomposition products corresponding to bases and ${\mathrm{{SO}}}_{3}$ to acids [47]. In the initial hot corrosion stage, the molten salt isolates the alloy matrix from the air, and sodium sulphate further decomposes to produce $\mathrm{O}$ and $\mathrm{S}$ , as shown in Eq. (1):

$$
{\mathrm{{Na}}}_{2}{\mathrm{{SO}}}_{4} = {\mathrm{{Na}}}_{2}\mathrm{O} + {\mathrm{{SO}}}_{3} = {\mathrm{{Na}}}_{2}\mathrm{O} + \frac{1}{2}\mathrm{\;S} + \frac{3}{2}{\mathrm{O}}_{2} \tag{1}
$$

The O atoms bond with outwardly diffused oxyphilic elements such as Ni, Cr, Al, and Ti. Ni, which has the highest content in the matrix, preferentially forms a uniform NiO layer at the interface. The formed ${\mathrm{{Cr}}}_{2}{\mathrm{O}}_{3}$ and ${\mathrm{{TiO}}}_{2}$ subsequently consumed part of the $\mathrm{{NiO}}$ to yield ${\mathrm{{NiCr}}}_{2}{\mathrm{O}}_{4}$ and ${\mathrm{{NiTiO}}}_{3}$ , thus providing better protection [48-50]. The following equations describe these reactions:

$$
\mathrm{{NiO}} + {\mathrm{{Cr}}}_{2}{\mathrm{O}}_{3} = {\mathrm{{NiCr}}}_{2}{\mathrm{O}}_{4} \tag{2}
$$

$$
\mathrm{{NiO}} + {\mathrm{{TiO}}}_{2} = {\mathrm{{NiTiO}}}_{3} \tag{3}
$$

However, owing to the low Cr and Ti contents in the alloy, a considerable amount of NiO still formed on the surface. Additionally, ${\mathrm{O}}^{2 - }$ easily penetrates the initial oxide layer and promotes the formation of a continuous ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ film below the outer oxide layer. The presence of a small amount of chlorine salts, owing to chloride volatility, disrupted the density of the ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ protective film, creating micro-holes throughout the layers. Simultaneously, the consumption of $\mathrm{O}$ promoted the decomposition of sodium sulphate, increasing the activity of $\mathrm{S}$ and allowing it to gradually diffuse inward, establishing a concentration gradient. Eventually, $S$ reacts with the metal atoms at equilibrium to produce sulphides (usually $\mathrm{{Cr}}$ and $\mathrm{{Ti}}$ sulphide). With the progress of hot corrosion, the increase in sulphides leads to sulphate desulphurization, increasing the activity of ${\mathrm{{Na}}}_{2}\mathrm{O}$ in the molten salt and increasing the alkalinity, causing basic fluxing as described in Eqs. (4) and (5):

$$
{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{3} + {\mathrm{{Na}}}_{2}\mathrm{O} = {\mathrm{{Na}}}_{2}{\mathrm{{Cr}}}_{2}{\mathrm{O}}_{4} \tag{4}
$$

$$
{\mathrm{{Al}}}_{2}{\mathrm{O}}_{3} + {\mathrm{{Na}}}_{2}\mathrm{O} = 2{\mathrm{{NaAlO}}}_{2} \tag{5}
$$

Owing to their low melting points, the generated ${\mathrm{{Cr}}}_{2}{\mathrm{O}}_{42}$ - and ${\mathrm{{AlO}}}_{22}$ - diffused outwards through the molten salt and deposited loose and unprotected products at the molten salt-gas interface [12]. The Ni oxide layer is highly unstable and gradually corroded due to the molten salt, resulting in the formation of numerous corrosion pits on the surface. The ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ protective film beneath it is gradually consumed by the molten salt, leading to the supplementation of Al from the substrate and the formation of large ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ particles.

![bo_d208ub3ef24c73anbarg_9_248_143_1253_1728_0.jpg](images/bo_d208ub3ef24c73anbarg_9_248_143_1253_1728_0.jpg)

Fig. 8. SEM images of the cross-sections of CMSX-4 specimens and corresponding EPMA mappings after hot corrosion at 900 oC for ${10}\mathrm{\;h},{110}\mathrm{\;h}$ and 200 $\mathrm{\;h}$ .

The experimental observation results of the CMSX-4 samples after hot corrosion under a mixture of ${\mathrm{{Na}}}_{2}{\mathrm{{SO}}}_{4}$ and $\mathrm{{NaCl}}$ at ${900}^{ \circ  }\mathrm{C}$ for ${200}\mathrm{\;h}$ are summarised in a process diagram, as shown in Fig. 17. The O and ${\mathrm{O}}^{2 - }$ produced by sulphate decomposition diffused into the substrate, and the oxyphilic elements in the substrate diffused outwards, as shown in Fig. 17 (a). Then, the basic structure of the corrosion product layer began to form, with a $\mathrm{{Ni}}$ -rich oxide (composed of $\mathrm{{NiO}},{\mathrm{{NiCr}}}_{2}{\mathrm{O}}_{4}$ and ${\mathrm{{NiTiO}}}_{3}$ ) on top and a continuous ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ film as the inner layer. Sulphides formed in the Al-depleted area with low O content, as depicted in Fig. 17 (b). The products of basic fluxing (rich in $\mathrm{{Cr}},\mathrm{{Co}}$ , and $\mathrm{{Ni}}$ ) precipitated at the gas-liquid interface and were vulnerable to attack. In the late stage of the hot corrosion reaction, as shown in Fig. 17 (c) and (d), the loose products on the surface began to peel off, the corrosion pits gradually enlarged, and the depth of the corrosion-affected zone increased. Multiple cracks were formed between the corrosion layers owing to stress. Further diffusion of $\mathrm{O}$ and $\mathrm{S}$ led to the gradual formation of a layered structure underneath the continuous ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ film comprising ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ and sulphide particles. Additionally, ${\mathrm{{Ta}}}_{2}{\mathrm{O}}_{5}$ enrichment zones were observed in a few areas between the layered structures, indicating that Ta plays an active role in resisting hot corrosion [51,52]. However, because Ta oxide is less stable than ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ a higher concentration of $\mathrm{O}$ is required to stabilise ${\mathrm{{Ta}}}_{2}{\mathrm{O}}_{5}$ [46]. This further indicates that the intrusion of $\mathrm{O}$ was severe during this period.

![bo_d208ub3ef24c73anbarg_10_335_157_1084_1405_0.jpg](images/bo_d208ub3ef24c73anbarg_10_335_157_1084_1405_0.jpg)

Fig. 9. Typical cross-sectional morphologies and element line distribution of CMSX-4 after hot corrosion at 900 °C for (a, b) 110 h and (c-e) 200 h.

#### 4.3.The role of ppm-level La

The process diagram shown in Fig. 18 summarises the results of the extensive observations and characterisations of the surface; it also shows the section of the modified alloy after the hot corrosion test. Overall, after ppm-level La modification, the basic features of the hot corrosion behaviour under the condition of ${900}^{ \circ  }\mathrm{C},{90}\% {\mathrm{{Na}}}_{2}{\mathrm{{SO}}}_{4} + {10}\% \mathrm{{NaCl}}$ deposition have not changed significantly. Similar to the unmodified alloy, said behaviour underwent the following stages: In Fig. 18 (a), O and ${\mathrm{O}}^{2 - }$ produced by sulphate decomposition diffused into the substrate, while Al, Cr, Ti, Ta, and other elements diffused to the surface. As shown in Fig. 18 (b), a mixed loose corrosion product layer rich in Ni, Co, Cr, and $\mathrm{O}$ formed rapidly on the surface of the alloy. Simultaneously, a continuous ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ protection film formed within the alloy, while a $\gamma$ ’/Al depleted zone formed near the unaffected matrix, with internal sulphides concentrated at the bottom of the Al-depleted zone. As shown in Fig. 18 (c), with prolonged corrosion time, partial spalling of the loose surface corrosion product layer occurred, local stratification occurred in the ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ protection film, internal ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ and sulphide particles increased, and the corrosion-affected area expanded. As shown in Fig. 18 (d), during the late corrosion period, the surface corrosion-product layer experienced significant spalling, accompanied by local thickening. The internal particles form a multi-layer structure, and the corrosion-affected zone expanded further.

![bo_d208ub3ef24c73anbarg_11_161_154_1423_1557_0.jpg](images/bo_d208ub3ef24c73anbarg_11_161_154_1423_1557_0.jpg)

Fig. 10. SEM images of the cross-sections of La-doped alloy specimens and corresponding EPMA mappings after hot corrosion at 900 oC for 10 h, 50 h and 200 h.

Compared with the hot corrosion process of the unmodified alloy, the differences are as follows: (1) The ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ protection layer in the modified alloy is denser, with rare micro-pores. However, ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ tends to grow inward in the form of a bud-shaped intrusion, leading to a higher local stress concentration. The outer layer adjacent to the bud growth is prone to delamination or micro-cracks. (2) Common concentration of ${\mathrm{{Ta}}}_{2}{\mathrm{O}}_{5}$ and ${\mathrm{{TiO}}}_{2}$ between the outer loose corrosion product layer and the inner ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ film, with local La detection consistent with $\mathrm{{Ti}}/\mathrm{{Ta}}$ element mapping. (3) The stratification of internal sulphides decreased, and the sulphides were mainly concentrated at the bottom of the Al-depleted area. (4) Although there were still micro-cracks between the layers, there were few surface corrosion pits, spalling was reduced, and surface smoothness improved.

The radius of the La atom(0.188nm)is much larger than that of the $\mathrm{{Ni}}$ atom(0.124nm), and the difference in electronegativity between the two is also large. Thus, it is not easy for La to form a solid solution in the $\mathrm{{Ni}}$ matrix. Due to its low solid solubility in the alloy, La segregates to form La-rich precipitates during solidification. As the binding ability of the active elements to $\mathrm{O}$ is greater, the La-rich precipitates are preferentially oxidised. These La oxides acted as short-circuit diffusion paths, promoting the internal diffusion of $\mathrm{O}$ to react with $\mathrm{{Al}}$ in the alloy and produce ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ nearby [53]. Furthermore, La doping increases the number of sub-grain boundary defects, thus promoting the diffusion of Al in the matrix. According to Wagner's oxidation theory [54], this was conducive to the transformation of the Al2O3 film from internal to external oxidation [55]. As a result, the densification of the Al2O3 protective layer improves, and the depleted zone of $\mathrm{{Al}}$ is reduced, confining the internal sulphides to the bottom of the Al-depleted zone.

![bo_d208ub3ef24c73anbarg_12_229_154_1289_644_0.jpg](images/bo_d208ub3ef24c73anbarg_12_229_154_1289_644_0.jpg)

Fig. 11. SEM images of the cross-sections of La-doped alloy specimens after hot corrosion. (a) BSE image; (b) SE image.

![bo_d208ub3ef24c73anbarg_12_123_899_1501_1014_0.jpg](images/bo_d208ub3ef24c73anbarg_12_123_899_1501_1014_0.jpg)

Fig. 12. Cross-sectional structure of corrosion products and La segregation after hot corrosion at 900 oC. (a) La segregation between Region I and Region II and the EDS line scanning patterns: ① Ti/La rich zone; ② Ta2O5 rich zone; (b) La segregation in Region II; (c) La segregation in Region I.

According to special phenomena, particularly the segregation of La, Fig. 18 (e) illustrates the possible action modes of La in the hot corrosion process. The three locations marked in the diagram correspond to the three typical areas of La segregation observed. In particular, Ti and Ta are active elements that exhibit high solid solubility in alloys. Once the precipitated La is oxidised, oxygen diffusion causes $\mathrm{{Ti}}$ and $\mathrm{{Ta}}$ to diffuse towards the La oxides. This diffusion leads to the formation of corresponding oxides when Ti and Ta combine with O [56]. As depicted in position $\mathbf{I}$ , an oxide peg structure was formed at the interface between the ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ oxide film and the matrix, as shown in Figs. 11 and 12 (b). This structure consisted of (La, Ti, Ta)-rich oxides as the core and ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ as the shell, which partially contributed to the formation of bud-shaped ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ . When the La oxides migrate to the interface of the external (Ni, Co, Cr) O layer and the ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ film (position II), as shown in Fig. 12 (a), the Ta and Ti oxides play a bonding role, according to the oxide pegging theory [57]. The local enrichment between the two corrosion layers helps accommodate the mismatch in the thermal expansion and contraction coefficients of the different products. Additionally, during hot corrosion, molten corrosion products act as a medium that accelerates the migration of metal cations and cation vacancies. These reactive element ions can utilise these pathways to diffuse from the substrate to the gas interface of the outer corrosion-product layer [58], as illustrated in position III. The reactive La ions segregate at the grain boundaries and metal-oxide interfaces, as shown in Fig. 10 (a) and 12 (c), refining the corrosion products and slowing the growth of interfacial voids [59]. Ultimately, the adhesion and protection of the loose-surface corrosion-product layer improved.

![bo_d208ub3ef24c73anbarg_13_379_146_990_1893_0.jpg](images/bo_d208ub3ef24c73anbarg_13_379_146_990_1893_0.jpg)

Fig. 13. STEM and SAED image of the interface region of corrosion layer and corresponding element mappings of O, Al, Cr, Ni, Co, Ta, Ti and La.

Table 6

Crystal structure characteristics of hot corrosion products in Fig. 13.

<table><tr><td>Position</td><td>Product</td><td>Lattice System</td><td>Space group</td><td>a</td><td>b</td><td>c</td><td>$\alpha$</td><td>$\beta$</td><td>Y</td></tr><tr><td>A</td><td>${\mathrm{{Cr}}}_{2}{\mathrm{O}}_{3}$</td><td>Trigonal</td><td>R3c</td><td>5.00</td><td>5.00</td><td>13.51</td><td>90</td><td>90</td><td>120</td></tr><tr><td>B</td><td>${\mathrm{{Ta}}}_{2}{\mathrm{O}}_{5}$</td><td>Orthorhombic</td><td>Pmmn</td><td>3.84</td><td>3.87</td><td>13.04</td><td>90</td><td>90</td><td>90</td></tr><tr><td>C</td><td>${\mathrm{{TiO}}}_{2}$</td><td>Orthorhombic</td><td>Pnma</td><td>2.97</td><td>10.67</td><td>17.53</td><td>90</td><td>90</td><td>90</td></tr><tr><td>D</td><td>NiO</td><td>FCC</td><td>Fm $\overline{3}\mathrm{m}$</td><td>4.19</td><td>4.19</td><td>4.19</td><td>90</td><td>90</td><td>90</td></tr><tr><td>E</td><td>${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$</td><td>Trigonal</td><td>R3c</td><td>4.81</td><td>4.81</td><td>13.12</td><td>90</td><td>90</td><td>120</td></tr></table>

![bo_d208ub3ef24c73anbarg_14_126_473_1499_506_0.jpg](images/bo_d208ub3ef24c73anbarg_14_126_473_1499_506_0.jpg)

Fig. 14. TEM characterization of La-containing oxides: (a) SEM image, (b) SAED image, and (c) HRTEM image.

![bo_d208ub3ef24c73anbarg_14_119_1078_1510_956_0.jpg](images/bo_d208ub3ef24c73anbarg_14_119_1078_1510_956_0.jpg)

Fig. 15. Surface relative height distribution of La-modified alloys after hot corrosion for 200 h. (a)~(d) surfaces of LaMA40; (e)~(h) surfaces of LaMA200.

Table 7

Surface roughness data of La-modified alloys after hot corrosion for ${200}\mathrm{\;h}$ .

<table><tr><td/><td>Average roughness (Sa)</td><td>Max peak height (Sp)</td><td>Max valley depth (Sv)</td><td>Skewness (Ssk)</td><td>Kurtosis (Sku)</td></tr><tr><td>LaMA40</td><td>9.614</td><td>48.978</td><td>-53.731</td><td>0.176</td><td>5.286</td></tr><tr><td>LaMA200</td><td>17.694</td><td>72.025</td><td>-64.503</td><td>0.608</td><td>3.783</td></tr></table>

![bo_d208ub3ef24c73anbarg_15_219_542_1304_1545_0.jpg](images/bo_d208ub3ef24c73anbarg_15_219_542_1304_1545_0.jpg)

Fig. 16. Corrosion characteristics of La-modified alloys. Cumulative probability plots of total corrosion depth and CP thickness for (a) LaMA40 and (b) LaMA200; Comparison showing the effect of La-doping amount on (c) CP thickness and (d) total corrosion depth; Cumulative probability plots of intrusion depth and outer CP thickness for (e) LaMA40 and (f) LaMA200.

![bo_d208ub3ef24c73anbarg_16_224_154_1301_906_0.jpg](images/bo_d208ub3ef24c73anbarg_16_224_154_1301_906_0.jpg)

Fig. 17. Schematic diagrams of the hot corrosion process of the unmodified CMSX-4 alloy, which are arranged in chronological order of hot corrosion. (a) sulphate decomposition and metal cation/oxygen ion diffusion; (b) typical structure of corrosion layer forming; (c) loose corrosion-products precipitated on the surface; (d) spalling and corrosion pits aggravating and layered structure forming inside.

In summary, the addition of La significantly enhances the alloy's thermal corrosion resistance. Compared to the results reported by Shi et al. [32] (using ${100}\mathrm{{ppm}}\mathrm{Y}$ ), our study demonstrates superior performance with only ${40}\mathrm{{ppm}}\mathrm{{La}}$ . For $\mathrm{{Ce}}$ , Seybolt et al. [34] suggested comparable improvement effects to La, though Ce predominantly forms ${\mathrm{{CeO}}}_{2}$ . In contrast, Gd exhibits markedly inferior performance. Regarding improvement mechanisms, both $\mathrm{Y}$ and $\mathrm{{La}}$ share similar roles: they do not alter the types of corrosion products but promote selective oxidation of Al. Both elements effectively reduce the spallation of corrosion products and facilitate the formation of protective corrosion layers on the alloy surface, thereby lowering corrosion rates [32]. Additionally, La and Ce demonstrate effective sulfur-scavenging capabilities that suppress internal sulfide formation, thereby enhancing hot corrosion resistance [34]. Notably, synergistic effects are frequently observed when multiple rare earth elements are co-added, resulting in enhanced corrosion resistance [35]. However, the underlying mechanisms governing this cooperative behavior require further elucidation.

## 5. Conclusions

The Type I hot corrosion behaviours of the Ni-based SC superalloy CMSX-4 and La-doped alloys (40/200 ppm La) were investigated under exposure to ${90}\% {\mathrm{{Na}}}_{2}{\mathrm{{SO}}}_{4} + {10}\% \mathrm{{NaCl}}$ at ${900}^{ \circ  }\mathrm{C}$ . The major conclusions

## are summarised as follows:

(1) ppm-level La doping significantly improved the hot corrosion resistance of the modified alloys. Notably, the weight gain curves of all the modified alloy samples exhibited longer weight gain "plateaus" compared to the unmodified alloy, which effectively demonstrates the hot corrosion rate of the stable period was reduced by more than half of the original.

(2) Within a certain range, increasing the La doping amount did not affect the hot corrosion kinetics of the modified alloy. The kinetic curves are divided into two stages of initiation and propagation. However, the modified alloy with higher La doping (200 ppm) exhibited greater individual variation in the middle and late stages of the corrosion test, potentially leading to an unstable modification effect.

(3) The La-modified alloy exhibited denser and more complete surface corrosion products than the unmodified alloy; the morphological features were also more prominent. Additionally, there was Ti and Ta enrichment in the cross-sectional corrosion layer, and inner ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ grew in the form of "bud invasion". Internal sulphides were confined to the bottom of the Al-depleted zone.

(4) Rare earth doping did not alter the basic hot corrosion features of the CMSX-4 alloy. La provides a short-circuit diffusion channel for $\mathrm{O}$ owing to segregation, increases the number of nucleation sites for oxides, and improves the densification of the ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ protective film. Furthermore, it promotes the enrichment and oxidation of $\mathrm{{Ti}}$ and $\mathrm{{Ta}}$ , thus playing an interlayer bonding role and improving the adhesion and protection of the surface of the unconsolidated corrosion-product layer.

![bo_d208ub3ef24c73anbarg_17_223_153_1309_1514_0.jpg](images/bo_d208ub3ef24c73anbarg_17_223_153_1309_1514_0.jpg)

Fig. 18. Schematic diagrams of the hot corrosion process of the modified alloy with ppm-level La doping, which are arranged in chronological order of hot corrosion. (a) sulphate decomposition and metal cation/oxygen ion diffusion; (b) La segregation and typical corrosion-layer forming; (c) loose corrosion-products precipitated and patched by $\mathrm{{Ti}}/\mathrm{{Ta}}$ oxides; (d) outer oxide-layer thickening and multi-layer of ${\mathrm{{Al}}}_{2}{\mathrm{O}}_{3}$ forming inside; (e) three typical areas of $\mathrm{{La}}$ -segregation and corresponding action modes.

## CRediT authorship contribution statement

Jianbo Yu: Methodology, Investigation. Jun Wang: Writing - review & editing, Data curation. Xiao Ma: Methodology, Investigation. Ruihao Yuan: Methodology, Investigation. Jiangkun Fan: Writing - original draft, Visualization, Investigation, Formal analysis, Data curation. Hongchao Kou: Writing - review & editing, Data curation. Zhongming Ren: Writing - review & editing, Data curation. Jinshan Li: Supervision, Funding acquisition. Dian Jiao: Investigation, Data curation. Zhiying Zhu: Investigation, Data curation. Jiayu Li: Writing - original draft, Visualization, Investigation, Formal analysis, Data curation. Yuelin Song: Investigation, Data curation.

## Declaration of Competing Interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

## Acknowledgements

This work was financially supported by the National Science and Technology Major Project (Nos. MJ-2018-G-48 and J2019-VI- 0023-0140) and the Research Fund of the State Key Laboratory of Solidification Processing (NPU) (Nos 2022-TS-04 and 2024-ZD-03).

## Appendix A. Supporting information

Supplementary data associated with this article can be found in the online version at doi:10.1016/j.jallcom.2025.181423.

## Data Availability

Data will be made available on request. References

[1] W.S. Xia, X.B. Zhao, L. Yue, Z. Zhang, A review of composition evolution in Ni-based single crystal superalloys, J. Mater. Sci. Technol. 44 (2020) 76-95.

[2] B. Wei, C. Chen, J. Xu, L. Yang, Y. Jia, Y. Du, M. Guo, C. Sun, Z. Wang, F. Wang, Comparing the hot corrosion of (100), (210) and (110) Ni-based superalloys exposed to the mixed salt of ${\mathrm{{Na}}}_{2}{\mathrm{{SO}}}_{4} - \mathrm{{NaCl}}$ at ${750}^{ \circ  }\mathrm{C}$ : experimental study and first-principles calculation, Corros. Sci. 195 (2022) 109996.

[3] S. Wee, J. Do, K. Kim, C. Lee, C. Seok, B.G. Choi, Y. Choi, W. Kim, Review on mechanical thermal properties of superalloys and thermal barrier coating used in gas turbines, Appl. Sci. 10 (16) (2020) 5476.

[4] P. Lortrakul, R.W. Trice, K.P. Trumble, M.A. Dayananda, Investigation of the mechanisms of Type-II hot corrosion of superalloy CMSX-4, Corros. Sci. 80 (2014) 408-415.

[5] J. Sumner, A. Encinas-Oropesa, N.J. Simms, J.R. Nicholls, Type II hot corrosion: Behavior of CMSX-4 and IN738LC as a function of corrosion environment, Materials and Corrosion 65 (2) (2013) 188-196.

[6] C.T. Sims, N.S. Stoloff, W.C. Hagel, Superalloys II, Wiley, New York, 1987.

[7] F. Pettit, Hot corrosion of metals and alloys, Oxid. Met. 76 (2011) 1-21.

[8] N. Eliaz, G. Shemesh, R.M. Latanision, Hot corrosion in gas turbine components, Eng. Fail Anal. 9 (1) (2002) 31-43.

[9] J.S. Meng, M.X. Chen, X.P. Shi, Q. Ma, Effect of Co on oxidation and hot corrosion behavior of two nickel-based superalloys under ${\mathrm{{Na}}}_{2}{\mathrm{{SO}}}_{4} - \mathrm{{NaCl}}$ at ${900}^{ \circ  }\mathrm{C}$ , T Nonferr Met. Soc. 31 (8) (2021) 2402-2414.

[10] M. Li, X. Sun, W. Hu, H. Guan, S. Chen, Hot Corrosion of a Single Crystal Ni-Base Superalloy by Na-Salts at ${900}^{ \circ  }\mathrm{C}$ , Oxid. Met. 65 (2006) 137-150.

[11] M. Qiao, C. Zhou, Hot corrosion behavior of Co modified NiAl coating on nickel base superalloys, Corros. Sci. 63 (2012) 239-245.

[12] J.W. Wang, C.Z. Zhang, Z.H. Li, H.X. Zhou, J.X. He, J.C. Yu, Corrosion behavior of nickel-based superalloys in thermal storage medium of molten eutectic $\mathrm{{NaCl}} - {\mathrm{{MgCl}}}_{2}$ in atmosphere, Sol. Energy Mater. Sol. Cells 164 (2017) 146-155.

[13] S. Sulzer, M. Hasselqvist, H. Murakami, P. Bagot, R. Reed, The effects of chemistry variations in new nickel-based superalloys for industrial gas turbine applications, Metall. Mater. Trans. A 51A (2020) 4902-4921.

[14] H. Long, S. Mao, Y. Liu, Z. Zhang, X. Han, Microstructural and compositional design of Ni-based single crystalline superalloys-A review, J. Alloy. Compd. 743 (2018) 203-220.

[15] B. Xu, H. Yin, X. Jiang, C. Zhang, R. Zhang, Y.W. Wang, X.H. Qu, Computational materials design: composition optimization to develop novel Ni-based single crystal superalloys, Comput. Mater. Sci. 202 (2022) 111021.

[16] R.C. Reed, Z. Zhu, A. Sato, D.J. Crudden, Isolation and testing of new single crystal superalloys using alloys-by-design method, Mater. Sci. Eng. A 667 (2016) 261-278.

[17] J.B. Wahl, K. Harris, CMSX-4 Plus Single Crystal Alloy Development, Characterization and Application Development, John Wiley & Sons, Inc, Hoboken, 2016, pp. 25-33.

[18] R.C. Reed, The Superalloys Fundamentals and Applications, Cambridge University Press, London, 2006.

[19] Z. Chen, T. Dong, W. Qu, Y. Ru, H. Zhang, Y. Pei, S. Gong, S. Li, Influence of Cr content on hot corrosion and a special tube sealing test of single crystal nickel base superalloy, Corros. Sci. 156 (2019) 161-170.

[20] S. Chandra, N. Paulose, R.K. Ra, The coupling effects of oxidation and temperature on the low cycle fatigue deformation behavior of CM 247 DS LC alloy, Int J. Fatigue 194 (2025) 108858.

[21] Y.Q. Yang, Y.C. Zhao, Z.X. Wen, J.J. Wang, M. Li, H.Q. Pei, Z.F. Yue, Study on the hot corrosion-creep failure mechanism of Ni-based single crystal superalloy considering the stress dependence, Mater. Sci. Eng. A 897 (2024) 146350.

[22] L. Brooking, S. Gray, J. Sumner, J.R. Nicholls, G. Marchant, Effect of stress state and simultaneous hot corrosion on the crack propagation and fatigue life of single crystal superalloy CMSX-4, Int J. Fatigue 116 (2018) 106-117.

[23] C.Y. Cui, G.M. Han, X.F. Sun, Effect of Ce addition on the microstructures and mechanical properties of a Ni-Co-based superalloy, Adv. Funct. Mater. 415 (2012) 2062-2065.

[24] P. Zhou, J. Yu, X. Sun, H. Guan, X. He, Z. Hu, Influence of Y on stress rupture property of a Ni-based superalloy, Mater. Sci. Eng. A 551 (2012) 236-240.

[25] P. Yu, Y.Q. Wang, Oxidation behavior of K38G superalloy with 0.1 mass% Yttrium addition at ${1000}^{ \circ  }\mathrm{C}$ in air, Corros, Sci. Prot. Technol. 19 (3) (2007) 189.

[26] F. Weng, H. Yu, C. Chen, K. Wan, Influence of Nb and Y on Hot Corrosion Behavior of Ni-Cr-based Superalloys, Mater. Manuf. Process 30 (5) (2014) 677-684.

[27] K.D. Xu, Z.M. Ren, C.J. Li, Progress in application of rare metals in superalloys, Rare Met 33 (2) (2014) 111-126.

[28] D.J. Harris, J.H. Harding, G.W. Watson, Computer simulation of the reactive element effect in NiO grain boundaries, Acta Mater. 48 (2000) 3039-3048.

[29] J. Jedliński, General aspects of the reactive element effect, Corros. Sci. 35 (1993) 863-869.

[30] H.B. Guo, D. Wang, H. Peng, S.K. Gong, H.B. Xu, Effect of Sm, Gd, Yb, Sc and Nd as reactive elements on oxidation behavior of $\beta$ -NiAl at ${1200}\mathrm{{oC}}$ , Corros. Sci. 78 (2014) 369-377.

[31] J. Stringer, The reactive element effect in high-temperature corrosion, Mater. Sci. Eng. A 120 (1989) 129-137.

[32] Z.X. Shi, S.Z. Liu, J.R. Li, Effect of yttrium on gas hot corrosion resistance of single crystal superalloy, Chin. Rare Earths 4 (2016) 81-85.

[33] J. Li, S. Liu, X. Wang, Development of a Low-Cost Third Generation Single Crystal Superalloy DD9, John Wiley & Sons, Inc, Hoboken, 2016, pp. 55-63.

[34] A.U. Seybolt, Role of rare earth additions in the phenomenon of hot corrosion, Corros. Sci. 11 (10) (1971) 751-761.

[35] K. Harris, J.B. Wahl, Improved single crystal superalloys, CMSX-4 (SLS)[La+Y] and CMSX-486, Superalloys (2004) 45-52.

[36] N.J. Simms, A. Encinas-Oropesa, J.R. Nicholls, Hot corrosion of coated and uncoated single crystal gas turbine materials, Mater. Corros. 59 (2008) 476-483.

[37] Y.Q. Yang, Y.C. Zhao, Z.X. Wen, G.X. Lu, H.Q. Pei, Z.F. Yue, Synergistic effect of multiple molten salts on hot corrosion behaviour of Ni-based single crystal superalloy, Corros. Sci. 204 (2022) 110381.

[38] J. Nicholls, S. Saunders, Hot-salt corrosion standards, test procedures and performance, High. Temp. Technol. 7 (4) (1989), 170-170.

[39] X. Montero, A. Ishida, T.M. Meißner, H. Murakami, M.C. Galetz, Effect of surface treatment and crystal orientation on hot corrosion of a Ni-based single-crystal superalloy, Corros. Sci. 166 (2020) 108472.

[40] J. Sumner, A. Encinas-Oropesa, N.J. Simms, Type II hot corrosion: kinetics studies of CMSX-4, Oxid. Met. 80 (56) (2013) 553-563.

[41] A.S. Chikhalikar, E.P. Godbole, D.L. Poerschke, Approach for statistical analysis of oxide- and sulfate-induced hot corrosion of advanced alloys, Corros. Sci. 211 (2023) 110892.

[42] X.L. Pan, H.Y. Yu, G.F. Tu, W.R. Sun, Z.Q. Hu, Effect of rare earth metals on solidification behavior in nickel-based superalloy, Mater. Sci. Technol. 28 (2012) 560.

[43] Z.X. Shi, S.Z. Liu, J.R. Li, Effect of Rare Earth Y on Microstructure and Stress Rupture Properties at High Temperature of Single Crystal Superalloy, Rare Met. Mat. Eng. 43 (5) (2014) 1138-1142.

[44] Y.Q. Yang, Z.X. Wen, Y.C. Zhao, W.J. Po, Z.W. Li, Z.F. Yue, Effect of crystallographic orientation on the corrosion resistance of Ni-based single crystal superalloys, Corros. Sci. 170 (2020) 108643.

[45] J.Y. Guédou, A. Kruk, B. Dubiel, A. Czyrska-Filemonowicz, J. Choné, Examination of chemical elements partitioning between the $\gamma$ and ${\gamma }^{\prime }$ phases in CMSX-4 superalloy using EDS microanalysis and electron tomography, MATEC Web Conf. 14 (2014) 11004.

[46] X. Yang, L. Yang, J. Wang, Z. Chen, M. Chen, J. Zhang, F. Wang, Investigation on the hot corrosion behavior of a single crystal $\mathrm{{Ni}}$ -based superalloy in molten ${\mathrm{{Na}}}_{2}{\mathrm{{SO}}}_{4}$ $+ {\mathrm{K}}_{2}{\mathrm{{SO}}}_{4}$ salts improved by different preoxidation treatments, Corros. Sci. 221 (2023) 111377.

[47] S. Hu, H. Finklea, X. Liu, A review on molten sulfate salts induced hot corrosion, J. Mater. Sci. Technol. 90 (2021) 243-254.

[48] J.X. Chang, D. Wang, X.G. Liu, L.H. Lou, J. Zhang, Effect of Rhenium addition on hot corrosion resistance of Ni-based single crystal Superalloys, Metall. Mater. Trans. A 49A (2018) 4343-4352.

[49] N. Baler, P. Pandey, M.P. Singh, S.K. Makineni, Effects of Ti and Cr additions in a Co- Ni-Al-Mo-Nb-based Superalloy, Superalloys (2020) 929-936.

[50] P. Song, M. Liu, X. Jiang, Y. Feng, J. Wu, G. Zhang, D. Wang, J. Dong, X.Q. Chen, L. Lou, Influence of alloying elements on hot corrosion resistance of nickel-based single crystal superalloys coated with ${\mathrm{{Na}}}_{2}{\mathrm{{SO}}}_{4}$ salt at ${900}^{ \circ  }\mathrm{C}$ , Mater. Des. 197 (2021) 109197.

[51] J.X. Chang, D. Wang, T. Liu, G. Zhang, L.H. Lou, J. Zhang, Role of tantalum in the hot corrosion of a Ni-base single crystal superalloy, Corros. Sci. 98 (2015) 585-591.

[52] J.X. Chang, D. Wang, G. Zhang, L.H. Lou, J. Zhang, Interaction of Ta and Cr on Type-I hot corrosion resistance of single crystal Ni-base superalloys, Corros. Sci. 117 (2017) 35-42.

[53] C. Mennicke, M.Y. He, D.R. Clarke, J.S. Smith, The role of secondary oxide inclusions "pegs" on the spalling resistance of oxide films, Acta Mater. 48 (2000) 2941-2949.

[54] D.E. Coates, A.D. Dalvi, An extension of the Wagner theory of alloy oxidation and sulfidation, Oxid. Met. 2 (1970) 331.

[55] P. Yu, Y.Q. Wang, W. Wang, Effect of reactive element yttrium on oxidation behavior of K38G superalloy at ${800}^{ \circ  }\mathrm{C}$ in air, Corros. Sci. Prot. Technol. 18 (3) (2006) 183.

[56] L. Yang, Y. Zheng, C.L. Wan, Q.M. Gong, C. Zhang, H. Chen, Z.G. Yang, Characteristics of oxide pegs in Ti- and Y-doped CoNiCrAl alloys at ${1150}^{ \circ  }\mathrm{C}$ , Rare Met 40 (2021) 2059-2064.

[57] B. Lustman, The intermittent oxidation of some nickel-chromium base alloys, JOM 2 (1950) 995-996.

[58] Z. Chen, W. Qu, Z. Zhang, J. Wang, M. Chen, S. Li, F. Wang, Hot corrosion mechanism of nickel-based single crystal superalloy IC21 under flowing atmosphere, Corros. Sci. 218 (2023) 111170.

[59] B.A. Pint, Experimental observations in support of the dynamic segregation theory to explain the reactive-element effect, Oxid. Met. 45 (1996) 1-37.